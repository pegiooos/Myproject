# GuestLab (from-scratch shell, Material 3)

STATUS: source only. Not compiled, not run, not tested on a device (the authoring sandbox had no
Kotlin compiler, Android SDK or network). Expect to fix small compile errors on first build.

## Build
    gradle wrapper --gradle-version 8.9      # no wrapper is bundled
    ./gradlew testDebugUnitTest assembleDebug

## What exists
- Boot animation changer: import .zip/.tar/.tar.gz/.tgz (bootanimation.zip, an archive containing one,
  or a folder with desc.txt), validation, in-app player, install, restore original.
- Install replaces every existing oem/product/system `media/bootanimation.zip` in the guest folder, backs up the
  first-seen originals, writes atomically, and reports success only after SHA-256 read-back matches.
- "Success" = verified on the guest's files. Whether the guest actually plays it is only known at next guest boot.

## What does NOT exist
- No emulation engine (QEMU etc.), so no guest can be started. Guests are extracted system folders placed in
  `Android/data/com.example.guestlab/files/guests/<name>/` (needs `system/media/` inside).
- ext4/sparse .img guests are not supported (no ext4 writer). Features 2 (spoofer) and 3 (Android 11) are not started.
- Guest file ownership/SELinux labels can't be set without root; install sets mode 0644 only.
