package com.example.guestlab

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.guestlab.ui.BootAnimationScreen
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            val scheme = if (Build.VERSION.SDK_INT >= 31) dynamicLightColorScheme(ctx) else lightColorScheme()
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize()) {
                    var selected by remember { mutableStateOf<File?>(null) }
                    BackHandler(selected != null) { selected = null }
                    val s = selected
                    if (s == null) GuestList { selected = it } else BootAnimationScreen(s) { selected = null }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GuestList(onOpen: (File) -> Unit) {
    val root = LocalContext.current.getExternalFilesDir("guests")
    val guests = remember { root?.listFiles { f -> f.isDirectory && !f.name.startsWith(".") }?.sortedBy { it.name } ?: emptyList() }
    Scaffold(topBar = { TopAppBar(title = { Text("GuestLab") }) }) { pad ->
        if (guests.isEmpty()) {
            Text("No guests yet. Place an extracted guest system folder in:\n${root?.path}", Modifier.padding(pad).padding(24.dp))
        } else LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(guests) { g ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(g) }, shape = MaterialTheme.shapes.extraLarge) {
                    Text(g.name, Modifier.padding(20.dp), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}
