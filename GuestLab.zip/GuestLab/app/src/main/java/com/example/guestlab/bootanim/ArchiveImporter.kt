package com.example.guestlab.bootanim

import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.zip.CRC32
import java.util.zip.GZIPInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Imports .zip / .tar / .tar.gz / .tgz. The archive may be a bootanimation.zip itself, a ROM/archive that
 * contains one, or a plain folder with desc.txt. Output is always a stored (uncompressed) bootanimation.zip.
 */
object ArchiveImporter {
    sealed interface Result {
        data class Ok(val file: File, val notes: List<String>) : Result
        data class Fail(val message: String) : Result
    }
    private enum class Kind { ZIP, TAR, TGZ }
    private const val MAX_BYTES = 600L * 1024 * 1024

    fun import(input: File, workDir: File): Result {
        workDir.deleteRecursively(); workDir.mkdirs()
        val extracted = File(workDir, "x").apply { mkdirs() }
        val notes = mutableListOf<String>()
        try {
            when (detect(input)) {
                Kind.ZIP -> extractZip(input, extracted)
                Kind.TAR -> input.inputStream().buffered().use { extractTar(it, extracted) }
                Kind.TGZ -> GZIPInputStream(input.inputStream().buffered()).use { extractTar(it, extracted) }
                null -> return Result.Fail("Unsupported file. Use .zip, .tar, .tar.gz or .tgz")
            }
            val dir = resolve(extracted, 0, notes) ?: return Result.Fail("No desc.txt or bootanimation.zip found in the archive")
            val out = File(workDir, "bootanimation.zip")
            packStored(dir, out)
            notes += "Repacked as an uncompressed (stored) ZIP, as Android requires."
            return Result.Ok(out, notes)
        } catch (e: Exception) {
            return Result.Fail("Could not read archive: ${e.message}")
        }
    }

    private fun detect(f: File): Kind? {
        val h = ByteArray(512)
        val n = f.inputStream().use { it.read(h) }
        if (n >= 4 && h[0] == 'P'.code.toByte() && h[1] == 'K'.code.toByte()) return Kind.ZIP
        if (n >= 2 && h[0] == 0x1f.toByte() && h[1] == 0x8b.toByte()) return Kind.TGZ
        if (n >= 262 && String(h, 257, 5, Charsets.US_ASCII) == "ustar") return Kind.TAR
        return null
    }

    private fun resolve(root: File, depth: Int, notes: MutableList<String>): File? {
        root.walkTopDown().maxDepth(3).firstOrNull { it.isFile && it.name == "desc.txt" }?.let { return it.parentFile }
        if (depth >= 1) return null
        val nested = root.walkTopDown().firstOrNull { it.isFile && it.name.equals("bootanimation.zip", true) } ?: return null
        notes += "Found bootanimation.zip inside the archive"
        val dest = File(root.parentFile, "nested").apply { deleteRecursively(); mkdirs() }
        extractZip(nested, dest)
        return resolve(dest, depth + 1, notes)
    }

    private fun safeTarget(dest: File, name: String): File {
        val t = File(dest, name).canonicalFile
        if (!t.path.startsWith(dest.canonicalPath + File.separator)) throw IOException("Unsafe path in archive: $name")
        return t
    }

    private fun extractZip(zipFile: File, dest: File) {
        var total = 0L
        ZipFile(zipFile).use { z ->
            for (e in z.entries()) {
                val t = safeTarget(dest, e.name)
                if (e.isDirectory) { t.mkdirs(); continue }
                t.parentFile?.mkdirs()
                z.getInputStream(e).use { ins -> t.outputStream().use { o ->
                    val buf = ByteArray(65536)
                    while (true) {
                        val r = ins.read(buf); if (r < 0) break
                        total += r; if (total > MAX_BYTES) throw IOException("Archive is too large")
                        o.write(buf, 0, r)
                    }
                } }
            }
        }
    }

    private fun extractTar(ins: InputStream, dest: File) {
        val hdr = ByteArray(512)
        var longName: String? = null
        var total = 0L
        while (true) {
            if (!readFully(ins, hdr)) break
            if (hdr.all { it == 0.toByte() }) break
            var name = cstr(hdr, 0, 100)
            if (String(hdr, 257, 5, Charsets.US_ASCII) == "ustar") {
                val prefix = cstr(hdr, 345, 155); if (prefix.isNotEmpty()) name = "$prefix/$name"
            }
            val size = cstr(hdr, 124, 12).trim().toLongOrNull(8) ?: throw IOException("Unsupported tar size field")
            val type = hdr[156].toInt().toChar()
            val pad = (512 - size % 512) % 512
            when (type) {
                'L', 'x' -> {
                    if (size > 1_000_000) throw IOException("Oversized tar header")
                    val data = ByteArray(size.toInt()); if (!readFully(ins, data)) throw IOException("Truncated tar")
                    skip(ins, pad)
                    val text = String(data, Charsets.UTF_8)
                    longName = if (type == 'L') text.trimEnd('\u0000')
                    else text.lines().map { it.substringAfter(' ', "") }.firstOrNull { it.startsWith("path=") }?.removePrefix("path=") ?: longName
                }
                '0', '\u0000' -> {
                    val t = safeTarget(dest, longName ?: name); longName = null
                    total += size; if (total > MAX_BYTES) throw IOException("Archive is too large")
                    t.parentFile?.mkdirs()
                    t.outputStream().use { o ->
                        var left = size; val buf = ByteArray(65536)
                        while (left > 0) {
                            val r = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                            if (r < 0) throw IOException("Truncated tar")
                            o.write(buf, 0, r); left -= r
                        }
                    }
                    skip(ins, pad)
                }
                '5' -> { safeTarget(dest, (longName ?: name).trimEnd('/')).mkdirs(); longName = null }
                else -> skip(ins, size + pad)
            }
        }
    }

    private fun cstr(b: ByteArray, off: Int, len: Int): String {
        var end = off; while (end < off + len && b[end] != 0.toByte()) end++
        return String(b, off, end - off, Charsets.UTF_8)
    }
    private fun readFully(s: InputStream, b: ByteArray): Boolean {
        var o = 0
        while (o < b.size) { val r = s.read(b, o, b.size - o); if (r < 0) return o != 0 && throw IOException("Truncated tar"); o += r }
        return true
    }
    private fun skip(s: InputStream, n: Long) {
        var left = n; val buf = ByteArray(8192)
        while (left > 0) { val r = s.read(buf, 0, minOf(buf.size.toLong(), left).toInt()); if (r < 0) throw IOException("Truncated tar"); left -= r }
    }

    private fun packStored(dir: File, out: File) {
        ZipOutputStream(out.outputStream().buffered()).use { zos ->
            val files = dir.walkTopDown().filter { it.isFile }.toList()
                .sortedWith(compareBy({ if (it.name == "desc.txt" && it.parentFile == dir) 0 else 1 }, { it.relativeTo(dir).path }))
            for (f in files) {
                val bytes = f.readBytes()
                val c = CRC32().apply { update(bytes) }
                val e = ZipEntry(f.relativeTo(dir).path.replace('\\', '/')).apply {
                    method = ZipEntry.STORED; size = bytes.size.toLong(); compressedSize = bytes.size.toLong(); crc = c.value
                }
                zos.putNextEntry(e); zos.write(bytes); zos.closeEntry()
            }
        }
    }
}
