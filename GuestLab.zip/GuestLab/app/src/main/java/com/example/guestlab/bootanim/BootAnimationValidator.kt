package com.example.guestlab.bootanim

import java.io.File
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

data class AnimPart(val type: Char, val loops: Int, val pause: Int, val dir: String, val colorHex: String?, val frames: List<String>)
data class AnimDesc(val width: Int, val height: Int, val fps: Int, val parts: List<AnimPart>)
enum class Severity { ERROR, WARNING }
data class Issue(val severity: Severity, val message: String)

data class ValidationResult(val desc: AnimDesc?, val issues: List<Issue>) {
    val ok: Boolean get() = desc != null && issues.none { it.severity == Severity.ERROR }
    val frameCount: Int get() = desc?.parts?.sumOf { it.frames.size } ?: 0
}

/** Validates a bootanimation.zip: stored ZIP, desc.txt grammar, part directories, real PNG frames. */
object BootAnimationValidator {
    const val MAX_ENTRIES = 20_000
    const val MAX_TOTAL_BYTES = 300L * 1024 * 1024
    private val PNG_SIG = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
    private val SPECIAL = setOf("trim.txt", "audio.wav")

    fun validate(file: File): ValidationResult {
        val issues = mutableListOf<Issue>()
        fun err(m: String) { issues += Issue(Severity.ERROR, m) }
        fun warn(m: String) { issues += Issue(Severity.WARNING, m) }

        val zip = try { ZipFile(file) } catch (e: Exception) {
            err("Not a readable ZIP file (${e.message})")
            return ValidationResult(null, issues)
        }
        return zip.use { z ->
            val entries = z.entries().asSequence().toList()
            if (entries.size > MAX_ENTRIES) { err("Too many entries (${entries.size})"); return@use ValidationResult(null, issues) }
            var total = 0L
            for (e in entries) {
                if (e.name.startsWith("/") || e.name.split('/').any { it == ".." }) {
                    err("Unsafe entry path: ${e.name}"); return@use ValidationResult(null, issues)
                }
                if (e.size > 0) total += e.size
            }
            if (total > MAX_TOTAL_BYTES) { err("Animation is too large when unpacked"); return@use ValidationResult(null, issues) }

            val descEntry = z.getEntry("desc.txt")
            if (descEntry == null) { err("desc.txt not found at the ZIP root"); return@use ValidationResult(null, issues) }
            if (descEntry.method != ZipEntry.STORED) warn("desc.txt is compressed; store it uncompressed for best compatibility")
            val lines = z.getInputStream(descEntry).bufferedReader().use { it.readLines() }
                .map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
            if (lines.isEmpty()) { err("desc.txt is empty"); return@use ValidationResult(null, issues) }

            val head = lines[0].split(Regex("\\s+"))
            val nums = head.take(3).map { it.toIntOrNull() }
            if (head.size < 3 || nums.any { it == null }) {
                err("First line of desc.txt must be: WIDTH HEIGHT FPS"); return@use ValidationResult(null, issues)
            }
            val (w, h, fps) = nums.map { it!! }
            if (w !in 1..8192 || h !in 1..8192) err("Unreasonable size ${w}x$h")
            if (fps !in 1..120) err("FPS must be 1..120 (got $fps)")
            if (head.size > 3) warn("Extra header fields are ignored by older Android versions")

            val parts = mutableListOf<AnimPart>()
            for (line in lines.drop(1)) {
                val t = line.split(Regex("\\s+"))
                if (t[0] != "p" && t[0] != "c") { warn("Unsupported desc.txt line ignored: \"$line\""); continue }
                val loops = t.getOrNull(1)?.toIntOrNull()
                val pause = t.getOrNull(2)?.toIntOrNull()
                val dir = t.getOrNull(3)
                if (loops == null || pause == null || dir == null || loops < 0 || pause < 0) {
                    err("Malformed part line (expected: p|c COUNT PAUSE DIR [#RRGGBB]): \"$line\""); continue
                }
                val color = t.getOrNull(4)
                if (color != null && !Regex("#[0-9A-Fa-f]{6}").matches(color)) warn("Ignoring background colour \"$color\" in part $dir")
                val prefix = "$dir/"
                val files = entries.filter { !it.isDirectory && it.name.startsWith(prefix) && !it.name.removePrefix(prefix).contains('/') }
                    .filter { it.name.removePrefix(prefix) !in SPECIAL }.sortedBy { it.name }
                if (files.isEmpty()) { err("Part \"$dir\" has no frame files"); continue }
                val frames = mutableListOf<String>()
                var sizeWarned = false
                for (f in files) {
                    when (f.name.substringAfterLast('.', "").lowercase()) {
                        "png" -> {
                            if (f.method != ZipEntry.STORED) { err("Frame ${f.name} is compressed; Android needs an uncompressed (stored) ZIP"); continue }
                            val b = z.getInputStream(f).use { readHead(it, 24) }
                            if (b.size < 24 || !b.copyOfRange(0, 8).contentEquals(PNG_SIG)) { err("${f.name} is not a valid PNG"); continue }
                            val fw = beInt(b, 16); val fh = beInt(b, 20)
                            if (!sizeWarned && (fw != w || fh != h)) { warn("Frames in $dir are ${fw}x$fh but desc.txt says ${w}x$h"); sizeWarned = true }
                            frames += f.name
                        }
                        "jpg", "jpeg" -> { warn("${f.name}: JPEG frames are not supported on all Android versions; use PNG"); }
                        else -> err("${f.name}: unsupported frame format (PNG required)")
                    }
                }
                parts += AnimPart(t[0][0], loops, pause, dir, color?.takeIf { Regex("#[0-9A-Fa-f]{6}").matches(it) }, frames)
            }
            if (parts.isEmpty()) err("desc.txt defines no usable parts")
            ValidationResult(AnimDesc(w, h, fps, parts), issues)
        }
    }

    private fun readHead(s: InputStream, n: Int): ByteArray {
        val buf = ByteArray(n); var off = 0
        while (off < n) { val r = s.read(buf, off, n - off); if (r < 0) break; off += r }
        return buf.copyOf(off)
    }
    private fun beInt(b: ByteArray, o: Int) = ((b[o].toInt() and 255) shl 24) or ((b[o + 1].toInt() and 255) shl 16) or ((b[o + 2].toInt() and 255) shl 8) or (b[o + 3].toInt() and 255)
}
