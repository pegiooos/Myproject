package com.example.guestlab.bootanim

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.nio.file.attribute.PosixFilePermissions
import java.security.MessageDigest

/**
 * Installs bootanimation.zip into an EXTRACTED guest filesystem directory (guestRoot/system/media/...).
 * Only files under guestRoot are touched; the host phone's own boot animation is never involved.
 * ext4/sparse .img guests are not supported here: the caller must expose them as a directory.
 */
class BootAnimationInstaller(private val guestRoot: File, private val backupDir: File) {
    companion object { const val NAME = "bootanimation.zip" }

    private val systemMedia = if (File(guestRoot, "system/system/build.prop").exists()) "system/system/media" else "system/media"
    private val locations = listOf("oem/media", "product/media", systemMedia)
    private val manifest = File(backupDir, "manifest.txt")

    sealed interface Outcome {
        data class Installed(val verifiedPaths: List<String>) : Outcome
        data class Restored(val verifiedPaths: List<String>) : Outcome
        data class Failed(val reason: String, val rolledBack: Boolean) : Outcome
    }
    private data class Entry(val rel: String, val existed: Boolean, val sha: String)

    fun installedAnimation(): File? = locations.map { File(guestRoot, "$it/$NAME") }.firstOrNull { it.isFile }
    fun hasBackup(): Boolean = manifest.isFile

    /** Replaces every bootanimation.zip that exists in the guest (so whichever the guest prefers is replaced). */
    fun install(source: File): Outcome {
        val v = BootAnimationValidator.validate(source)
        if (!v.ok) return Outcome.Failed("Validation failed: " + v.issues.filter { it.severity == Severity.ERROR }.joinToString("; ") { it.message }, false)

        var targets = locations.map { it to File(guestRoot, "$it/$NAME") }.filter { it.second.isFile }
        if (targets.isEmpty()) {
            val dir = File(guestRoot, systemMedia)
            if (!dir.isDirectory) return Outcome.Failed("Guest has no $systemMedia directory; is this an extracted guest system?", false)
            targets = listOf(systemMedia to File(dir, NAME))
        }
        for ((rel, f) in targets) {
            if (!f.parentFile!!.canWrite()) return Outcome.Failed("$rel is not writable by the app (read-only or permission denied). Nothing was changed.", false)
        }
        try { snapshot(targets) } catch (e: IOException) { return Outcome.Failed("Could not create backup, nothing changed: ${e.message}", false) }

        val want = sha256(source)
        val touched = mutableListOf<Pair<String, File>>()
        try {
            for ((rel, f) in targets) {
                touched += rel to f
                atomicCopy(source, f)
                if (sha256(f) != want) throw IOException("read-back mismatch for $rel")
            }
        } catch (e: Exception) {
            return Outcome.Failed("Install failed: ${e.message}", rollback(touched))
        }
        return Outcome.Installed(targets.map { "${it.first}/$NAME" })
    }

    /** Restores the state captured before the first install; success only after read-back matches. */
    fun restore(): Outcome {
        val entries = load()
        if (entries.isEmpty()) return Outcome.Failed("No backup found for this guest", false)
        for (e in entries) {
            val f = File(guestRoot, "${e.rel}/$NAME")
            if ((e.existed || f.exists()) && !f.parentFile!!.canWrite()) return Outcome.Failed("${e.rel} is not writable. Nothing was changed.", false)
        }
        val failed = entries.filterNot { restoreEntry(it) }
        if (failed.isNotEmpty()) return Outcome.Failed("Could not restore: " + failed.joinToString { it.rel }, false)
        backupDir.deleteRecursively()
        return Outcome.Restored(entries.map { "${it.rel}/$NAME" })
    }

    private fun backupFile(rel: String) = File(backupDir, "files/" + rel.replace('/', '_'))

    private fun snapshot(targets: List<Pair<String, File>>) {
        val known = load().associateBy { it.rel }.toMutableMap()
        for ((rel, f) in targets) {
            if (rel in known) continue
            if (f.isFile) {
                val b = backupFile(rel); b.parentFile!!.mkdirs()
                FileInputStream(f).use { i -> FileOutputStream(b).use { o -> i.copyTo(o); o.fd.sync() } }
                if (sha256(b) != sha256(f)) throw IOException("backup verification failed")
                known[rel] = Entry(rel, true, sha256(b))
            } else known[rel] = Entry(rel, false, "-")
        }
        backupDir.mkdirs()
        manifest.writeText(known.values.joinToString("\n") { "${it.rel}\t${if (it.existed) 1 else 0}\t${it.sha}" })
    }

    private fun load(): List<Entry> =
        if (!manifest.isFile) emptyList()
        else manifest.readLines().filter { it.isNotBlank() }.map { l -> l.split('\t').let { Entry(it[0], it[1] == "1", it[2]) } }

    private fun rollback(touched: List<Pair<String, File>>): Boolean {
        val byRel = load().associateBy { it.rel }
        return touched.all { (rel, _) -> byRel[rel]?.let { restoreEntry(it) } ?: false }
    }

    private fun restoreEntry(e: Entry): Boolean = try {
        val f = File(guestRoot, "${e.rel}/$NAME")
        if (e.existed) { atomicCopy(backupFile(e.rel), f); sha256(f) == e.sha } else { f.delete(); !f.exists() }
    } catch (ex: Exception) { false }

    private fun atomicCopy(src: File, dest: File) {
        val tmp = File(dest.parentFile, ".${dest.name}.tmp")
        try {
            FileInputStream(src).use { i -> FileOutputStream(tmp).use { o -> i.copyTo(o); o.fd.sync() } }
            runCatching { Files.setPosixFilePermissions(tmp.toPath(), PosixFilePermissions.fromString("rw-r--r--")) }
            try { Files.move(tmp.toPath(), dest.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING) }
            catch (e: AtomicMoveNotSupportedException) { Files.move(tmp.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING) }
        } finally { tmp.delete() }
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(f).use { i -> val b = ByteArray(65536); while (true) { val r = i.read(b); if (r < 0) break; md.update(b, 0, r) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
