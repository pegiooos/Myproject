package com.example.guestlab.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.example.guestlab.bootanim.BootAnimationValidator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

/** Plays a bootanimation.zip using its own desc.txt (fps, parts, loops, pauses, background colour). */
@Composable
fun BootAnimationPreview(zip: File, modifier: Modifier = Modifier) {
    var frame by remember(zip) { mutableStateOf<ImageBitmap?>(null) }
    var bg by remember(zip) { mutableStateOf(Color.Black) }
    var error by remember(zip) { mutableStateOf<String?>(null) }

    LaunchedEffect(zip) {
        withContext(Dispatchers.IO) {
            val desc = BootAnimationValidator.validate(zip).desc
            if (desc == null) { error = "Cannot preview: invalid animation"; return@withContext }
            ZipFile(zip).use { z ->
                val frameMs = 1000L / desc.fps
                val opts = BitmapFactory.Options().apply { inSampleSize = if (desc.width >= 1080) 2 else 1 }
                while (isActive) {
                    for (part in desc.parts) {
                        part.colorHex?.let { c -> runCatching { bg = Color(android.graphics.Color.parseColor(c)) } }
                        val repeats = if (part.loops == 0) 2 else part.loops   // preview: endless parts play twice
                        repeat(repeats) {
                            for (name in part.frames) {
                                if (!isActive) return@withContext
                                val e = z.getEntry(name) ?: continue
                                frame = z.getInputStream(e).use { BitmapFactory.decodeStream(it, null, opts) }?.asImageBitmap()
                                delay(frameMs)
                            }
                            delay(part.pause * frameMs)
                        }
                    }
                }
            }
        }
    }

    Box(modifier.background(bg), contentAlignment = Alignment.Center) {
        val f = frame
        when {
            error != null -> Text(error!!, color = Color.White)
            f != null -> Image(f, contentDescription = "Boot animation preview", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        }
    }
}
