package com.example.guestlab.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.guestlab.bootanim.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BootAnimationScreen(guest: File, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val installer = remember(guest) { BootAnimationInstaller(guest, File(ctx.getExternalFilesDir("backups"), "${guest.name}/bootanim")) }
    var refresh by remember { mutableIntStateOf(0) }
    var candidate by remember { mutableStateOf<File?>(null) }
    var validation by remember { mutableStateOf<ValidationResult?>(null) }
    var notes by remember { mutableStateOf<List<String>>(emptyList()) }
    var status by remember { mutableStateOf<Pair<Boolean, String>?>(null) }   // (isError, text)
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true; status = null
            val r = withContext(Dispatchers.IO) {
                val src = File(ctx.cacheDir, "import-src").apply { delete() }
                ctx.contentResolver.openInputStream(uri)?.use { i -> src.outputStream().use { i.copyTo(it) } }
                when (val imp = ArchiveImporter.import(src, File(ctx.cacheDir, "bootanim-import"))) {
                    is ArchiveImporter.Result.Ok -> Triple(imp.file, BootAnimationValidator.validate(imp.file), imp.notes)
                    is ArchiveImporter.Result.Fail -> { status = true to imp.message; null }
                }
            }
            candidate = r?.first; validation = r?.second; notes = r?.third ?: emptyList()
            busy = false
        }
    }

    fun report(o: BootAnimationInstaller.Outcome) {
        status = when (o) {
            is BootAnimationInstaller.Outcome.Installed ->
                false to "Installed and verified by read-back in the guest: ${o.verifiedPaths.joinToString()}. The guest will show it on its next boot."
            is BootAnimationInstaller.Outcome.Restored ->
                false to "Original restored and verified: ${o.verifiedPaths.joinToString()}."
            is BootAnimationInstaller.Outcome.Failed ->
                true to (o.reason + if (o.rolledBack) " Changes were rolled back." else "")
        }
        refresh++
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Boot animation · ${guest.name}") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            val current = remember(refresh) { installer.installedAnimation() }
            Card(shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Currently in guest", style = MaterialTheme.typography.titleMedium)
                    if (current == null) Text("No bootanimation.zip found in this guest.")
                    else BootAnimationPreview(current, Modifier.fillMaxWidth().height(320.dp).clip(MaterialTheme.shapes.large))
                }
            }
            Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Import .zip / .tar / .tar.gz…") }

            candidate?.let { file ->
                Card(shape = MaterialTheme.shapes.extraLarge) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Imported animation", style = MaterialTheme.typography.titleMedium)
                        BootAnimationPreview(file, Modifier.fillMaxWidth().height(320.dp).clip(MaterialTheme.shapes.large))
                        validation?.let { v ->
                            v.desc?.let { Text("${it.width}×${it.height} @ ${it.fps} fps · ${it.parts.size} parts · ${v.frameCount} frames") }
                            v.issues.forEach { Text((if (it.severity == Severity.ERROR) "Error: " else "Warning: ") + it.message) }
                            notes.forEach { Text(it) }
                        }
                        Button(onClick = {
                            scope.launch { busy = true; report(withContext(Dispatchers.IO) { installer.install(file) }); busy = false }
                        }, enabled = !busy && validation?.ok == true) { Text("Install to guest") }
                    }
                }
            }
            OutlinedButton(onClick = {
                scope.launch { busy = true; report(withContext(Dispatchers.IO) { installer.restore() }); busy = false }
            }, enabled = !busy && installer.hasBackup()) { Text("Restore original") }

            status?.let { (isErr, text) ->
                Card(colors = CardDefaults.cardColors(containerColor = if (isErr) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer)) {
                    Text(text, Modifier.padding(16.dp))
                }
            }
        }
    }
}
