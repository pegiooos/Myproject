package com.example.guestlab

import com.example.guestlab.bootanim.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.Base64
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class BootAnimationTest {
    @get:Rule val tmp = TemporaryFolder()
    private val png = Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==")

    private fun makeZip(name: String, stored: Boolean, desc: String? = "1 1 10\np 1 0 part0\n", prefix: String = ""): File {
        val f = tmp.newFile(name)
        ZipOutputStream(f.outputStream()).use { z ->
            fun put(n: String, b: ByteArray) {
                val e = ZipEntry(prefix + n)
                if (stored) { e.method = ZipEntry.STORED; e.size = b.size.toLong(); e.compressedSize = e.size; e.crc = CRC32().also { it.update(b) }.value }
                z.putNextEntry(e); z.write(b); z.closeEntry()
            }
            if (desc != null) put("desc.txt", desc.toByteArray())
            put("part0/0001.png", png); put("part0/0002.png", png)
        }
        return f
    }

    @Test fun validStoredZipPasses() {
        val r = BootAnimationValidator.validate(makeZip("a.zip", true))
        assertTrue(r.issues.toString(), r.ok); assertEquals(2, r.frameCount)
    }
    @Test fun compressedFramesRejected() = assertFalse(BootAnimationValidator.validate(makeZip("b.zip", false)).ok)
    @Test fun missingDescRejected() = assertFalse(BootAnimationValidator.validate(makeZip("c.zip", true, desc = null)).ok)
    @Test fun nonZipRejected() = assertFalse(BootAnimationValidator.validate(tmp.newFile("d.zip").apply { writeText("nope") }).ok)

    @Test fun importerRepacksFolderInsideCompressedZip() {
        val r = ArchiveImporter.import(makeZip("e.zip", false, prefix = "MyAnim/"), tmp.newFolder("work"))
        assertTrue(r.toString(), r is ArchiveImporter.Result.Ok)
        assertTrue(BootAnimationValidator.validate((r as ArchiveImporter.Result.Ok).file).ok)
    }

    @Test fun installVerifyAndRestoreOriginal() {
        val guest = tmp.newFolder("guest"); val media = File(guest, "system/media").apply { mkdirs() }
        val orig = File(media, "bootanimation.zip").apply { writeBytes(byteArrayOf(1, 2, 3)) }
        val inst = BootAnimationInstaller(guest, tmp.newFolder("bk"))
        val src = makeZip("f.zip", true)
        assertTrue(inst.install(src) is BootAnimationInstaller.Outcome.Installed)
        assertArrayEquals(src.readBytes(), orig.readBytes())
        assertTrue(inst.install(src) is BootAnimationInstaller.Outcome.Installed)   // 2nd install keeps true original
        assertTrue(inst.restore() is BootAnimationInstaller.Outcome.Restored)
        assertArrayEquals(byteArrayOf(1, 2, 3), orig.readBytes())
    }

    @Test fun invalidAnimationNeverTouchesGuest() {
        val guest = tmp.newFolder("g2"); File(guest, "system/media").mkdirs()
        val r = BootAnimationInstaller(guest, tmp.newFolder("bk2")).install(makeZip("g.zip", false))
        assertTrue(r is BootAnimationInstaller.Outcome.Failed)
        assertFalse(File(guest, "system/media/bootanimation.zip").exists())
    }
}
